/**
 * Digititup Agency Pvt. Ltd. - 3D Google Earth Global Unicorns Engine
 * Precise City & Country Intelligence System
 * Dual Modes: "By Unicorns (Companies)" & "By Country (1,286 WPR Ranking)"
 */

(function () {
  'use strict';

  /* ==========================================================================
     1. Complete 55-Country Ranking Dataset (World Population Review)
        1,286 Total Unicorns | $4.6T Total Valuation
     ========================================================================== */
  const COUNTRIES_DATA = [
  {
    "rank": 1,
    "country": "United States",
    "code": "US",
    "flag": "\ud83c\uddfa\ud83c\uddf8",
    "count": 712,
    "valuation": "$2.9T",
    "valNumber": 2900,
    "lat": 37.0902,
    "lng": -95.7129,
    "capital_cities": "San Francisco, New York, Los Angeles, Austin, Seattle",
    "top": "OpenAI, SpaceX, Stripe, Databricks, Anthropic, Scale AI"
  },
  {
    "rank": 2,
    "country": "China",
    "code": "CN",
    "flag": "\ud83c\udde8\ud83c\uddf3",
    "count": 157,
    "valuation": "$687.1B",
    "valNumber": 687.1,
    "lat": 35.8617,
    "lng": 104.1954,
    "capital_cities": "Beijing, Shenzhen, Shanghai, Hangzhou",
    "top": "ByteDance, DJI, SHEIN, Xiaohongshu"
  },
  {
    "rank": 3,
    "country": "India",
    "code": "IN",
    "flag": "\ud83c\uddee\ud83c\uddf3",
    "count": 69,
    "valuation": "$164B",
    "valNumber": 164,
    "lat": 20.5937,
    "lng": 78.9629,
    "capital_cities": "Bengaluru, Mumbai, Delhi NCR, Hyderabad",
    "top": "PhonePe, Flipkart, Swiggy, Razorpay, Postman, Zepto, OYO"
  },
  {
    "rank": 4,
    "country": "United Kingdom",
    "code": "GB",
    "flag": "\ud83c\uddec\ud83c\udde7",
    "count": 55,
    "valuation": "$190B",
    "valNumber": 190,
    "lat": 55.3781,
    "lng": -3.436,
    "capital_cities": "London, Cambridge, Oxford, Manchester",
    "top": "Revolut, Checkout.com, Wayve, Wise, Synthesia, Monzo"
  },
  {
    "rank": 5,
    "country": "Germany",
    "code": "DE",
    "flag": "\ud83c\udde9\ud83c\uddea",
    "count": 32,
    "valuation": "$86B",
    "valNumber": 86,
    "lat": 51.1657,
    "lng": 10.4515,
    "capital_cities": "Munich, Berlin, Cologne, Hamburg",
    "top": "Celonis, DeepL, Delivery Hero, N26, Personio, Flix"
  },
  {
    "rank": 6,
    "country": "France",
    "code": "FR",
    "flag": "\ud83c\uddeb\ud83c\uddf7",
    "count": 29,
    "valuation": "$72.9B",
    "valNumber": 72.9,
    "lat": 46.2276,
    "lng": 2.2137,
    "capital_cities": "Paris, Lyon, Marseille",
    "top": "Mistral AI, Back Market, Sorare, Qonto, Doctolib, ManoMano"
  },
  {
    "rank": 7,
    "country": "Israel",
    "code": "IL",
    "flag": "\ud83c\uddee\ud83c\uddf1",
    "count": 25,
    "valuation": "$47.4B",
    "valNumber": 47.4,
    "lat": 31.0461,
    "lng": 34.8516,
    "capital_cities": "Tel Aviv, Herzliya, Haifa",
    "top": "Rapyd, Wiz, Gong, Monday.com, ironSource, DriveNets"
  },
  {
    "rank": 8,
    "country": "Canada",
    "code": "CA",
    "flag": "\ud83c\udde8\ud83c\udde6",
    "count": 22,
    "valuation": "$57.5B",
    "valNumber": 57.5,
    "lat": 56.1304,
    "lng": -106.3468,
    "capital_cities": "Toronto, Vancouver, Montreal",
    "top": "1Password, Cohere, Dapper Labs, Clio, Clearco, Ada"
  },
  {
    "rank": 9,
    "country": "Brazil",
    "code": "BR",
    "flag": "\ud83c\udde7\ud83c\uddf7",
    "count": 18,
    "valuation": "$37.1B",
    "valNumber": 37.1,
    "lat": -14.235,
    "lng": -51.9253,
    "capital_cities": "S\u00e3o Paulo, Rio de Janeiro, Belo Horizonte",
    "top": "Nubank, QuintoAndar, C6 Bank, Wildlife Studios, Loft, CloudWalk"
  },
  {
    "rank": 10,
    "country": "South Korea",
    "code": "KR",
    "flag": "\ud83c\uddf0\ud83c\uddf7",
    "count": 14,
    "valuation": "$33.4B",
    "valNumber": 33.4,
    "lat": 35.9078,
    "lng": 127.7669,
    "capital_cities": "Seoul, Pangyo Techno Valley",
    "top": "Toss (Viva Republica), Coupang, Krafton, Yanolja, Musinsa"
  },
  {
    "rank": 11,
    "country": "Singapore",
    "code": "SG",
    "flag": "\ud83c\uddf8\ud83c\uddec",
    "count": 14,
    "valuation": "$87.8B",
    "valNumber": 87.8,
    "lat": 1.3521,
    "lng": 103.8198,
    "capital_cities": "Singapore (One-North & CBD)",
    "top": "SHEIN, Grab, Carousell, PatSnap, Ninja Van, Bolttech"
  },
  {
    "rank": 12,
    "country": "Mexico",
    "code": "MX",
    "flag": "\ud83c\uddf2\ud83c\uddfd",
    "count": 9,
    "valuation": "$13.7B",
    "valNumber": 13.7,
    "lat": 23.6345,
    "lng": -102.5528,
    "capital_cities": "Mexico City, Guadalajara, Monterrey",
    "top": "Kavak, Bitso, Clip, Clara, Nowports, Merama"
  },
  {
    "rank": 13,
    "country": "Japan",
    "code": "JP",
    "flag": "\ud83c\uddef\ud83c\uddf5",
    "count": 9,
    "valuation": "$11.8B",
    "valNumber": 11.8,
    "lat": 36.2048,
    "lng": 138.2529,
    "capital_cities": "Tokyo, Kyoto, Osaka",
    "top": "Preferred Networks, SmartHR, Spiber, Playco, Paidy"
  },
  {
    "rank": 14,
    "country": "Australia",
    "code": "AU",
    "flag": "\ud83c\udde6\ud83c\uddfa",
    "count": 9,
    "valuation": "$48.8B",
    "valNumber": 48.8,
    "lat": -25.2744,
    "lng": 133.7751,
    "capital_cities": "Sydney, Melbourne, Brisbane",
    "top": "Canva, Airwallex, SafetyCulture, Immutable, Employment Hero"
  },
  {
    "rank": 15,
    "country": "Netherlands",
    "code": "NL",
    "flag": "\ud83c\uddf3\ud83c\uddf1",
    "count": 9,
    "valuation": "$24.5B",
    "valNumber": 24.5,
    "lat": 52.1326,
    "lng": 5.2913,
    "capital_cities": "Amsterdam, Rotterdam, Utrecht",
    "top": "Mollie, MessageBird (Bird), Bunq, Mambu, Crisp"
  },
  {
    "rank": 16,
    "country": "Ireland",
    "code": "IE",
    "flag": "\ud83c\uddee\ud83c\uddea",
    "count": 9,
    "valuation": "$13.7B",
    "valNumber": 13.7,
    "lat": 53.1424,
    "lng": -7.6921,
    "capital_cities": "Dublin (Silicon Docks), Cork",
    "top": "Stripe (dual-HQ), Wayflyer, Flipdish, Workhuman, Fenergo"
  },
  {
    "rank": 17,
    "country": "Indonesia",
    "code": "ID",
    "flag": "\ud83c\uddee\ud83c\udde9",
    "count": 7,
    "valuation": "$10.4B",
    "valNumber": 10.4,
    "lat": -0.7893,
    "lng": 113.9213,
    "capital_cities": "Jakarta, Bandung, Surabaya",
    "top": "GoTo, J&T Express, Traveloka, Kopi Kenangan, Ajaib, Xendit"
  },
  {
    "rank": 18,
    "country": "Hong Kong",
    "code": "HK",
    "flag": "\ud83c\udded\ud83c\uddf0",
    "count": 7,
    "valuation": "$9.7B",
    "valNumber": 9.7,
    "lat": 22.3193,
    "lng": 114.1694,
    "capital_cities": "Hong Kong (Cyberport & Science Park)",
    "top": "Animoca Brands, Lalamove, Klook, Amber Group"
  },
  {
    "rank": 19,
    "country": "Sweden",
    "code": "SE",
    "flag": "\ud83c\uddf8\ud83c\uddea",
    "count": 6,
    "valuation": "$22.1B",
    "valNumber": 22.1,
    "lat": 60.1282,
    "lng": 18.6435,
    "capital_cities": "Stockholm, Gothenburg, Malm\u00f6",
    "top": "Klarna, Northvolt, Kry, Einride, Voi Technology"
  },
  {
    "rank": 20,
    "country": "Switzerland",
    "code": "CH",
    "flag": "\ud83c\udde8\ud83c\udded",
    "count": 6,
    "valuation": "$9.8B",
    "valNumber": 9.8,
    "lat": 46.8182,
    "lng": 8.2275,
    "capital_cities": "Zurich, Lausanne, Geneva",
    "top": "MindMaze, Scandit, SonarSource, Nexthink, Sportradar"
  },
  {
    "rank": 21,
    "country": "Spain",
    "code": "ES",
    "flag": "\ud83c\uddea\ud83c\uddf8",
    "count": 5,
    "valuation": "$7.7B",
    "valNumber": 7.7,
    "lat": 40.4637,
    "lng": -3.7492,
    "capital_cities": "Madrid, Barcelona, Valencia",
    "top": "Cabify, TravelPerk, Factorial, Jobandtalent, Recover"
  },
  {
    "rank": 22,
    "country": "United Arab Emirates",
    "code": "AE",
    "flag": "\ud83c\udde6\ud83c\uddea",
    "count": 5,
    "valuation": "$9.3B",
    "valNumber": 9.3,
    "lat": 23.4241,
    "lng": 53.8478,
    "capital_cities": "Dubai (DIFC), Abu Dhabi (ADGM)",
    "top": "Careem, Kitopi, Vista Global, Tabby, Yango"
  },
  {
    "rank": 23,
    "country": "Norway",
    "code": "NO",
    "flag": "\ud83c\uddf3\ud83c\uddf4",
    "count": 5,
    "valuation": "$5.5B",
    "valNumber": 5.5,
    "lat": 60.472,
    "lng": 8.4689,
    "capital_cities": "Oslo, Bergen, Trondheim",
    "top": "Oda, Cognite, Gelato, Dune Analytics, Kahoot!"
  },
  {
    "rank": 24,
    "country": "Colombia",
    "code": "CO",
    "flag": "\ud83c\udde8\ud83c\uddf4",
    "count": 4,
    "valuation": "$8.4B",
    "valNumber": 8.4,
    "lat": 4.5709,
    "lng": -74.2973,
    "capital_cities": "Bogot\u00e1, Medell\u00edn, Cali",
    "top": "Rappi, Habi, Platzi, La Haus"
  },
  {
    "rank": 25,
    "country": "Finland",
    "code": "FI",
    "flag": "\ud83c\uddeb\ud83c\uddee",
    "count": 4,
    "valuation": "$14.9B",
    "valNumber": 14.9,
    "lat": 61.9241,
    "lng": 25.7482,
    "capital_cities": "Helsinki, Espoo, Tampere",
    "top": "Wolt, Supercell, Oura, Aiven"
  },
  {
    "rank": 26,
    "country": "Italy",
    "code": "IT",
    "flag": "\ud83c\uddee\ud83c\uddf9",
    "count": 3,
    "valuation": "$4.5B",
    "valNumber": 4.5,
    "lat": 41.8719,
    "lng": 12.5674,
    "capital_cities": "Milan, Rome, Turin",
    "top": "Satispay, Scalapay, Bending Spoons"
  },
  {
    "rank": 27,
    "country": "Belgium",
    "code": "BE",
    "flag": "\ud83c\udde7\ud83c\uddea",
    "count": 3,
    "valuation": "$11.9B",
    "valNumber": 11.9,
    "lat": 50.5039,
    "lng": 4.4699,
    "capital_cities": "Brussels, Ghent, Antwerp",
    "top": "Collibra, Deliverect, team.blue"
  },
  {
    "rank": 28,
    "country": "Nigeria",
    "code": "NG",
    "flag": "\ud83c\uddf3\ud83c\uddec",
    "count": 2,
    "valuation": "$3B",
    "valNumber": 3,
    "lat": 9.082,
    "lng": 8.6753,
    "capital_cities": "Lagos (Yabacon Valley), Abuja",
    "top": "Flutterwave, OPay, Interswitch, Andela"
  },
  {
    "rank": 29,
    "country": "Vietnam",
    "code": "VN",
    "flag": "\ud83c\uddfb\ud83c\uddf3",
    "count": 2,
    "valuation": "$5.3B",
    "valNumber": 5.3,
    "lat": 14.0583,
    "lng": 108.2772,
    "capital_cities": "Ho Chi Minh City, Hanoi",
    "top": "VNG, VNLife (VNPay), MoMo"
  },
  {
    "rank": 30,
    "country": "Thailand",
    "code": "TH",
    "flag": "\ud83c\uddf9\ud83c\udded",
    "count": 2,
    "valuation": "$2.5B",
    "valNumber": 2.5,
    "lat": 15.87,
    "lng": 100.9925,
    "capital_cities": "Bangkok, Chiang Mai",
    "top": "Flash Express, Ascend Money, Line Man Wongnai"
  },
  {
    "rank": 31,
    "country": "Chile",
    "code": "CL",
    "flag": "\ud83c\udde8\ud83c\uddf1",
    "count": 2,
    "valuation": "$2.5B",
    "valNumber": 2.5,
    "lat": -35.6751,
    "lng": -71.543,
    "capital_cities": "Santiago (Chilecon Valley)",
    "top": "NotCo, Betterfly"
  },
  {
    "rank": 32,
    "country": "Greece",
    "code": "GR",
    "flag": "\ud83c\uddec\ud83c\uddf7",
    "count": 2,
    "valuation": "$3.3B",
    "valNumber": 3.3,
    "lat": 39.0742,
    "lng": 21.8243,
    "capital_cities": "Athens, Thessaloniki",
    "top": "Viva Wallet, Blueground"
  },
  {
    "rank": 33,
    "country": "Austria",
    "code": "AT",
    "flag": "\ud83c\udde6\ud83c\uddf9",
    "count": 2,
    "valuation": "$7.6B",
    "valNumber": 7.6,
    "lat": 47.5162,
    "lng": 14.5501,
    "capital_cities": "Vienna, Graz, Linz",
    "top": "Bitpanda, GoStudent"
  },
  {
    "rank": 34,
    "country": "Denmark",
    "code": "DK",
    "flag": "\ud83c\udde9\ud83c\uddf0",
    "count": 2,
    "valuation": "$6.7B",
    "valNumber": 6.7,
    "lat": 56.2639,
    "lng": 9.5018,
    "capital_cities": "Copenhagen, Aarhus",
    "top": "Pleo, Lunar, Sitecore"
  },
  {
    "rank": 35,
    "country": "Croatia",
    "code": "HR",
    "flag": "\ud83c\udded\ud83c\uddf7",
    "count": 2,
    "valuation": "$3B",
    "valNumber": 3,
    "lat": 45.1,
    "lng": 15.2,
    "capital_cities": "Zagreb, Split",
    "top": "Rimac Automobili, Infobip"
  },
  {
    "rank": 36,
    "country": "Lithuania",
    "code": "LT",
    "flag": "\ud83c\uddf1\ud83c\uddf9",
    "count": 2,
    "valuation": "$8.4B",
    "valNumber": 8.4,
    "lat": 55.1694,
    "lng": 23.8813,
    "capital_cities": "Vilnius, Kaunas",
    "top": "Vinted, Nord Security"
  },
  {
    "rank": 37,
    "country": "Estonia",
    "code": "EE",
    "flag": "\ud83c\uddea\ud83c\uddea",
    "count": 2,
    "valuation": "$9.9B",
    "valNumber": 9.9,
    "lat": 58.5953,
    "lng": 25.0136,
    "capital_cities": "Tallinn, Tartu",
    "top": "Bolt, Wise, Veriff, Pipedrive"
  },
  {
    "rank": 38,
    "country": "Seychelles",
    "code": "SC",
    "flag": "\ud83c\uddf8\ud83c\udde8",
    "count": 2,
    "valuation": "$11.8B",
    "valNumber": 11.8,
    "lat": -4.6796,
    "lng": 55.492,
    "capital_cities": "Victoria, Mah\u00e9",
    "top": "KuCoin, OKX Exchange"
  },
  {
    "rank": 39,
    "country": "Egypt",
    "code": "EG",
    "flag": "\ud83c\uddea\ud83c\uddec",
    "count": 1,
    "valuation": "$1B",
    "valNumber": 1,
    "lat": 26.8206,
    "lng": 30.8025,
    "capital_cities": "Cairo, Alexandria, Giza",
    "top": "MNT-Halan, Fawry"
  },
  {
    "rank": 40,
    "country": "Philippines",
    "code": "PH",
    "flag": "\ud83c\uddf5\ud83c\udded",
    "count": 1,
    "valuation": "$1B",
    "valNumber": 1,
    "lat": 12.8797,
    "lng": 121.774,
    "capital_cities": "Manila (BGC & Makati)",
    "top": "Mynt (GCash), Voyager Innovations"
  },
  {
    "rank": 41,
    "country": "Turkey",
    "code": "TR",
    "flag": "\ud83c\uddf9\ud83c\uddf7",
    "count": 1,
    "valuation": "$2B",
    "valNumber": 2,
    "lat": 38.9637,
    "lng": 35.2433,
    "capital_cities": "Istanbul, Ankara, Izmir",
    "top": "Trendyol, Getir, Peak Games, Dream Games"
  },
  {
    "rank": 42,
    "country": "South Africa",
    "code": "ZA",
    "flag": "\ud83c\uddff\ud83c\udde6",
    "count": 1,
    "valuation": "$1.6B",
    "valNumber": 1.6,
    "lat": -30.5595,
    "lng": 22.9375,
    "capital_cities": "Cape Town, Johannesburg",
    "top": "Promasidor, Go1"
  },
  {
    "rank": 43,
    "country": "Argentina",
    "code": "AR",
    "flag": "\ud83c\udde6\ud83c\uddf7",
    "count": 1,
    "valuation": "$2.8B",
    "valNumber": 2.8,
    "lat": -38.4161,
    "lng": -63.6167,
    "capital_cities": "Buenos Aires, C\u00f3rdoba",
    "top": "Ual\u00e1, Tiendanube, Auth0"
  },
  {
    "rank": 44,
    "country": "Uzbekistan",
    "code": "UZ",
    "flag": "UZ",
    "count": 1,
    "valuation": "$1.2B",
    "valNumber": 1.2,
    "lat": 41.3775,
    "lng": 64.5853,
    "capital_cities": "Tashkent, Samarkand",
    "top": "Uzum Superapp & Digital Banking"
  },
  {
    "rank": 45,
    "country": "Malaysia",
    "code": "MY",
    "flag": "\ud83c\uddf2\ud83c\uddfe",
    "count": 1,
    "valuation": "$1.7B",
    "valNumber": 1.7,
    "lat": 4.2105,
    "lng": 101.9758,
    "capital_cities": "Kuala Lumpur, Cyberjaya",
    "top": "Carsome Automobile E-Commerce"
  },
  {
    "rank": 46,
    "country": "Saudi Arabia",
    "code": "SA",
    "flag": "\ud83c\uddf8\ud83c\udde6",
    "count": 1,
    "valuation": "$1B",
    "valNumber": 1,
    "lat": 23.8859,
    "lng": 45.0792,
    "capital_cities": "Riyadh, Jeddah",
    "top": "Tamara, Jahez, Floward"
  },
  {
    "rank": 47,
    "country": "Senegal",
    "code": "SN",
    "flag": "\ud83c\uddf8\ud83c\uddf3",
    "count": 1,
    "valuation": "$1.7B",
    "valNumber": 1.7,
    "lat": 14.4974,
    "lng": -14.4524,
    "capital_cities": "Dakar",
    "top": "Wave Mobile Money"
  },
  {
    "rank": 48,
    "country": "Ecuador",
    "code": "EC",
    "flag": "\ud83c\uddea\ud83c\udde8",
    "count": 1,
    "valuation": "$1.5B",
    "valNumber": 1.5,
    "lat": -1.8312,
    "lng": -78.1834,
    "capital_cities": "Quito, Guayaquil",
    "top": "Kushki Payment Infrastructure"
  },
  {
    "rank": 49,
    "country": "Czechia",
    "code": "CZ",
    "flag": "\ud83c\udde8\ud83c\uddff",
    "count": 1,
    "valuation": "$1.2B",
    "valNumber": 1.2,
    "lat": 49.8175,
    "lng": 15.473,
    "capital_cities": "Prague, Brno",
    "top": "Rohlik Group Online Grocery"
  },
  {
    "rank": 50,
    "country": "Portugal",
    "code": "PT",
    "flag": "\ud83c\uddf5\ud83c\uddf9",
    "count": 1,
    "valuation": "$1.3B",
    "valNumber": 1.3,
    "lat": 39.3999,
    "lng": -8.2245,
    "capital_cities": "Lisbon, Porto",
    "top": "OutSystems, Talkdesk, Feedzai"
  },
  {
    "rank": 51,
    "country": "New Zealand",
    "code": "NZ",
    "flag": "\ud83c\uddf3\ud83c\uddff",
    "count": 1,
    "valuation": "$1B",
    "valNumber": 1,
    "lat": -40.9006,
    "lng": 174.886,
    "capital_cities": "Auckland, Wellington",
    "top": "Rocket Lab, Allbirds"
  },
  {
    "rank": 52,
    "country": "Luxembourg",
    "code": "LU",
    "flag": "\ud83c\uddf1\ud83c\uddfa",
    "count": 1,
    "valuation": "$2B",
    "valNumber": 2,
    "lat": 49.8153,
    "lng": 6.1296,
    "capital_cities": "Luxembourg City",
    "top": "Talkwalker Consumer Intelligence"
  },
  {
    "rank": 53,
    "country": "Malta",
    "code": "MT",
    "flag": "\ud83c\uddf2\ud83c\uddf9",
    "count": 1,
    "valuation": "$1B",
    "valNumber": 1,
    "lat": 35.9375,
    "lng": 14.3754,
    "capital_cities": "Valletta, Sliema",
    "top": "VistaJet Luxury Aviation"
  },
  {
    "rank": 54,
    "country": "Cayman Islands",
    "code": "KY",
    "flag": "\ud83c\uddf0\ud83c\uddfe",
    "count": 1,
    "valuation": "$1B",
    "valNumber": 1,
    "lat": 19.3133,
    "lng": -81.2546,
    "capital_cities": "George Town",
    "top": "Chainalysis Blockchain Forensics"
  },
  {
    "rank": 55,
    "country": "Liechtenstein",
    "code": "LI",
    "flag": "\ud83c\uddf1\ud83c\uddee",
    "count": 1,
    "valuation": "$1B",
    "valNumber": 1,
    "lat": 47.166,
    "lng": 9.5554,
    "capital_cities": "Vaduz",
    "top": "Bittrex Global Digital Assets"
  }
];

  /* ==========================================================================
     1B. Premier Global Unicorns Dataset (Exact City Coordinates)
     ========================================================================== */
  const UNICORNS_DATA = [
    // --- NORTH AMERICA ---
    {
      id: 'openai',
      name: 'OpenAI',
      valuation: '$157 Billion',
      valNumber: 157,
      category: 'AI & Foundation Models',
      city: 'San Francisco',
      country: 'United States',
      lat: 37.7749,
      lng: -122.4194,
      founded: 2015,
      founders: 'Sam Altman, Greg Brockman, Ilya Sutskever',
      investors: 'Microsoft, Thrive Capital, Khosla Ventures, SoftBank',
      tagline: 'Frontier Artificial General Intelligence & ChatGPT',
      summary: 'Pioneered modern generative artificial intelligence with GPT-4, ChatGPT, and Sora. Represents the definitive foundation layer of the 21st-century technological epoch.',
      synergy: 'Digititup Tech builds enterprise AI pipelines directly on OpenAI architectures; Digititup Media produces investigative explainers deconstructing frontier model research.',
      url: 'https://openai.com'
    },
    {
      id: 'spacex',
      name: 'SpaceX',
      valuation: '$180+ Billion',
      valNumber: 180,
      category: 'Aerospace & Frontier Tech',
      city: 'Hawthorne',
      country: 'United States',
      lat: 33.9207,
      lng: -118.3278,
      founded: 2002,
      founders: 'Elon Musk',
      investors: 'Founders Fund, Sequoia Capital, Fidelity, Baillie Gifford',
      tagline: 'Reusable Orbital Launch Vehicles & Starlink Constellation',
      summary: 'Revolutionized space exploration with the Falcon 9 and Starship reusable rocket systems, while democratizing global low-latency satellite internet via Starlink.',
      synergy: 'Serves as an inspiration for first-principles engineering rigor—the exact discipline applied by Digititup\'s IOE Pulchowk engineering founders.',
      url: 'https://spacex.com'
    },
    {
      id: 'anthropic',
      name: 'Anthropic',
      valuation: '$18.5 Billion',
      valNumber: 18.5,
      category: 'AI & Foundation Models',
      city: 'San Francisco',
      country: 'United States',
      lat: 37.7897,
      lng: -122.4014,
      founded: 2021,
      founders: 'Dario Amodei, Daniela Amodei',
      investors: 'Amazon, Alphabet (Google), Spark Capital, Menlo Ventures',
      tagline: 'Constitutional AI Safety & Claude Frontier Models',
      summary: 'Creators of Claude 3.5 Sonnet and Constitutional AI. Dedicated to engineering safe, steerable, and reliable frontier intelligence for mission-critical enterprise workflows.',
      synergy: 'Key foundation layer utilized across Digititup Academy\'s high-retention coding workflows and Digititup Tech\'s automated software auditing engines.',
      url: 'https://anthropic.com'
    },
    {
      id: 'stripe',
      name: 'Stripe',
      valuation: '$65 Billion',
      valNumber: 65,
      category: 'Fintech & Payments',
      city: 'South San Francisco',
      country: 'United States',
      lat: 37.6547,
      lng: -122.4077,
      founded: 2010,
      founders: 'Patrick Collison, John Collison',
      investors: 'Sequoia Capital, Andreessen Horowitz, Founders Fund, General Catalyst',
      tagline: 'Global Economic Infrastructure for the Internet',
      summary: 'Processes hundreds of billions of dollars annually for modern digital businesses, from solo creator software to multinational conglomerates.',
      synergy: 'The gold standard of API-first developer documentation and compounding SaaS infrastructure that Digititup Tech models in client builds.',
      url: 'https://stripe.com'
    },
    {
      id: 'databricks',
      name: 'Databricks',
      valuation: '$43 Billion',
      valNumber: 43,
      category: 'Enterprise SaaS',
      city: 'San Francisco',
      country: 'United States',
      lat: 37.7915,
      lng: -122.3999,
      founded: 2013,
      founders: 'Ali Ghodsi, Matei Zaharia, Ion Stoica',
      investors: 'Andreessen Horowitz, New Enterprise Associates, CapitalG, Tiger Global',
      tagline: 'Unified Data Lakehouse & Enterprise AI Platform',
      summary: 'Pioneered the Lakehouse data architecture combining data warehouses and data lakes with open-source Apache Spark and generative model development.',
      synergy: 'Architectural blueprint for high-throughput data processing and telemetry analytics.',
      url: 'https://databricks.com'
    },
    {
      id: 'scale-ai',
      name: 'Scale AI',
      valuation: '$13.8 Billion',
      valNumber: 13.8,
      category: 'AI & Foundation Models',
      city: 'San Francisco',
      country: 'United States',
      lat: 37.7785,
      lng: -122.4150,
      founded: 2016,
      founders: 'Alexandr Wang, Lucy Guo',
      investors: 'Accel, Index Ventures, Founders Fund, Coatue, Greenoaks',
      tagline: 'Critical Data Infrastructure for Generative AI',
      summary: 'The primary training data annotation and model evaluation platform utilized by OpenAI, Meta, Google, and the US Department of Defense.',
      synergy: 'Highlights the immense leverage of combining human annotation talent with machine verification, echoing Digititup Academy\'s talent funnel.',
      url: 'https://scale.com'
    },
    {
      id: 'perplexity',
      name: 'Perplexity AI',
      valuation: '$3.0 Billion',
      valNumber: 3,
      category: 'AI & Foundation Models',
      city: 'San Francisco',
      country: 'United States',
      lat: 37.7799,
      lng: -122.4080,
      founded: 2022,
      founders: 'Aravind Srinivas, Denis Yarats, Johnny Ho, Andy Konwinski',
      investors: 'Jeff Bezos, IVP, NEA, Databricks Ventures, Elad Gil',
      tagline: 'Conversational Answer Engine & Live Knowledge Synthesis',
      summary: 'Transforming web search from static ten blue links into dynamic, citation-backed conversational intelligence synthesized in real time.',
      synergy: 'Pratik Chaudhary\'s commitment to 100% verified citations in public explainers directly matches Perplexity\'s real-time citation philosophy.',
      url: 'https://perplexity.ai'
    },
    {
      id: 'figma',
      name: 'Figma',
      valuation: '$12.5 Billion',
      valNumber: 12.5,
      category: 'Enterprise SaaS',
      city: 'San Francisco',
      country: 'United States',
      lat: 37.7752,
      lng: -122.4175,
      founded: 2012,
      founders: 'Dylan Field, Evan Wallace',
      investors: 'Index Ventures, Greylock, Kleiner Perkins, Sequoia Capital',
      tagline: 'Browser-Based Collaborative Interface Design Platform',
      summary: 'Unifies design, prototyping, developer handoff, and creative collaboration into a real-time multiplayer WebGL canvas.',
      synergy: 'Used across all Digititup venture design pipelines, thumbnail concepting, and frontend UI wireframing.',
      url: 'https://figma.com'
    },
    {
      id: 'notion',
      name: 'Notion',
      valuation: '$10.0 Billion',
      valNumber: 10,
      category: 'Enterprise SaaS',
      city: 'San Francisco',
      country: 'United States',
      lat: 37.7610,
      lng: -122.4190,
      founded: 2013,
      founders: 'Ivan Zhao, Simon Last',
      investors: 'Index Ventures, Sequoia Capital, Coatue Management',
      tagline: 'All-in-One Connected Workspace & AI Docs',
      summary: 'Consolidated docs, wikis, project management, and AI assistance into a customizable block-based operating system for knowledge teams.',
      synergy: 'Digititup Academy runs masterclasses showing thousands of students how to automate business workflows using Notion and AI.',
      url: 'https://notion.so'
    },
    {
      id: 'midjourney',
      name: 'Midjourney',
      valuation: '$10+ Billion',
      valNumber: 10,
      category: 'Media & Creator Tech',
      city: 'San Francisco',
      country: 'United States',
      lat: 37.7850,
      lng: -122.4060,
      founded: 2022,
      founders: 'David Holz',
      investors: '100% Bootstrapped / Self-Funded ($0 External VC)',
      tagline: 'Hyper-Profitable Bootstrapped Visual Generative AI',
      summary: 'Generated hundreds of millions in net revenue with a lean team of under 100 people and zero venture capital funding. The ultimate triumph of capital efficiency.',
      synergy: 'Core inspiration for Digititup\'s lean studio ethos—proving that exceptional product leverage trumps head-count bloat.',
      url: 'https://midjourney.com'
    },
    {
      id: 'runway',
      name: 'Runway ML',
      valuation: '$1.5 Billion',
      valNumber: 1.5,
      category: 'Media & Creator Tech',
      city: 'New York',
      country: 'United States',
      lat: 40.7128,
      lng: -74.0060,
      founded: 2018,
      founders: 'Cristóbal Valenzuela, Alejandro Matamala, Anastasis Germanidis',
      investors: 'Felicis Ventures, Amplify Partners, Google, NVIDIA, Salesforce',
      tagline: 'Generative AI Video Production & Gen-3 Diffusion Systems',
      summary: 'Powers next-generation cinematic video creation, controllable camera motions, and generative visual effects for Hollywood and creators alike.',
      synergy: 'Directly utilized by Digititup Media for synthetic B-roll generation and advanced documentary visual sequences.',
      url: 'https://runwayml.com'
    },
    {
      id: 'cohere',
      name: 'Cohere',
      valuation: '$5.5 Billion',
      valNumber: 5.5,
      category: 'AI & Foundation Models',
      city: 'Toronto',
      country: 'Canada',
      lat: 43.6532,
      lng: -79.3832,
      founded: 2019,
      founders: 'Aidan Gomez, Nick Frosst, Ivan Zhang',
      investors: 'NVIDIA, Oracle, Salesforce Ventures, Cisco, Index Ventures',
      tagline: 'Enterprise-Grade Retrieval Augmented Language AI',
      summary: 'Founded by co-authors of the seminal "Attention Is All You Need" paper. Delivers enterprise multilingual embeddings and secure on-prem LLMs.',
      synergy: 'Key technology studied and taught inside Digititup Academy enterprise seminars.',
      url: 'https://cohere.com'
    },
    {
      id: 'epic-games',
      name: 'Epic Games',
      valuation: '$32 Billion',
      valNumber: 32,
      category: 'Media & Creator Tech',
      city: 'Cary',
      country: 'United States',
      lat: 35.7915,
      lng: -78.7811,
      founded: 1991,
      founders: 'Tim Sweeney',
      investors: 'Sony, Tencent, Disney, KKR, Smash Ventures',
      tagline: 'Unreal Engine 5 & Next-Generation Realtime 3D',
      summary: 'Developers of Unreal Engine, powering top-tier AAA video games, Hollywood virtual production stages, and architectural simulations.',
      synergy: 'Supplies the 3D rendering standards that inspire Digititup Tech\'s interactive WebGL interactive systems.',
      url: 'https://epicgames.com'
    },
    {
      id: 'elevenlabs',
      name: 'ElevenLabs',
      valuation: '$1.1 Billion',
      valNumber: 1.1,
      category: 'Media & Creator Tech',
      city: 'New York',
      country: 'United States',
      lat: 40.7589,
      lng: -73.9851,
      founded: 2022,
      founders: 'Piotr Dabkowski, Mati Staniszewski',
      investors: 'Andreessen Horowitz, Nat Friedman, Daniel Gross, Sequoia Capital',
      tagline: 'Hyper-Realistic Multilingual Voice AI Synthesis',
      summary: 'Industry standard for AI voice generation, instant voice cloning, and emotional speech inflection across 30+ languages.',
      synergy: 'Integral to Digititup Media\'s video localization workflows across regional South Asian dialects.',
      url: 'https://elevenlabs.io'
    },

    // --- EUROPE & UK ---
    {
      id: 'mistral',
      name: 'Mistral AI',
      valuation: '$6.2 Billion',
      valNumber: 6.2,
      category: 'AI & Foundation Models',
      city: 'Paris',
      country: 'France',
      lat: 48.8566,
      lng: 2.3522,
      founded: 2023,
      founders: 'Arthur Mensch, Guillaume Lample, Timothée Lacroix',
      investors: 'Lightspeed Venture Partners, General Catalyst, Andreessen Horowitz, NVIDIA',
      tagline: 'Europe\'s Champion in Open-Weights Frontier AI',
      summary: 'Engineered Mixtral and Mistral Large with unmatched parameter efficiency, rivaling proprietary models at a fraction of computational cost.',
      synergy: 'Empowers Digititup Tech to deploy private, self-hosted AI models for clients with absolute data sovereignty.',
      url: 'https://mistral.ai'
    },
    {
      id: 'revolut',
      name: 'Revolut',
      valuation: '$45 Billion',
      valNumber: 45,
      category: 'Fintech & Payments',
      city: 'London',
      country: 'United Kingdom',
      lat: 51.5074,
      lng: -0.1278,
      founded: 2015,
      founders: 'Nikolay Storonsky, Vlad Yatsenko',
      investors: 'SoftBank Vision Fund, Tiger Global, Coatue, Index Ventures',
      tagline: 'Global Financial Superapp with 45M+ Users',
      summary: 'Cross-border currency exchange, retail banking, crypto, stock trading, and merchant acquiring all unified into a single frictionless mobile app.',
      synergy: 'Exemplifies the power of building a zero-fee consumer hook to cross-sell high-margin financial products.',
      url: 'https://revolut.com'
    },
    {
      id: 'wayve',
      name: 'Wayve',
      valuation: '$3.0 Billion',
      valNumber: 3,
      category: 'AI & Foundation Models',
      city: 'London',
      country: 'United Kingdom',
      lat: 51.5245,
      lng: -0.0987,
      founded: 2017,
      founders: 'Alex Kendall, Amar Shah',
      investors: 'SoftBank, NVIDIA, Microsoft, Eclipse Ventures, Balderton Capital',
      tagline: 'Embodied AI & End-to-End Autonomous Driving',
      summary: 'Pioneering "AV2.0" by training end-to-end foundation models that learn driving intuition directly from visual sensors without rigid rule-based code.',
      synergy: 'Highlights the frontier crossover between deep reinforcement learning and robotics.',
      url: 'https://wayve.ai'
    },
    {
      id: 'checkout',
      name: 'Checkout.com',
      valuation: '$11.0 Billion',
      valNumber: 11,
      category: 'Fintech & Payments',
      city: 'London',
      country: 'United Kingdom',
      lat: 51.5155,
      lng: -0.0922,
      founded: 2012,
      founders: 'Guillaume Pousaz',
      investors: 'Insight Partners, Tiger Global, DST Global, GIC, Coatue',
      tagline: 'High-Volume Enterprise Cloud Payment Processing',
      summary: 'Modular payment platform processing transactions for Netflix, Sony, Grab, and SHEIN across 150+ currencies.',
      synergy: 'Demonstrates the power of capital-efficient B2B infrastructure with astronomical gross margins.',
      url: 'https://checkout.com'
    },
    {
      id: 'deepl',
      name: 'DeepL',
      valuation: '$2.0 Billion',
      valNumber: 2,
      category: 'AI & Foundation Models',
      city: 'Cologne',
      country: 'Germany',
      lat: 50.9375,
      lng: 6.9603,
      founded: 2017,
      founders: 'Jaroslaw Kutylowski',
      investors: 'Index Ventures, IVP, Benchmark, Atomico',
      tagline: 'World\'s Most Accurate Neural Translation Engine',
      summary: 'Built a neural machine translation network that consistently outperforms Big Tech incumbents through proprietary linguistic deep learning.',
      synergy: 'Proves a focused European AI specialist can establish an unassailable quality moat against generalist tech monopolies.',
      url: 'https://deepl.com'
    },
    {
      id: 'celonis',
      name: 'Celonis',
      valuation: '$13.0 Billion',
      valNumber: 13,
      category: 'Enterprise SaaS',
      city: 'Munich',
      country: 'Germany',
      lat: 48.1351,
      lng: 11.5820,
      founded: 2011,
      founders: 'Alexander Rinke, Bastian Nominacher, Martin Klenk',
      investors: 'Accel, 83North, Arena Holdings, T. Rowe Price',
      tagline: 'Global Leader in Process Mining & Business Execution Systems',
      summary: 'Extracts real-time digital footprints from enterprise ERP and CRM systems to automatically identify operational friction and eliminate billions in corporate waste.',
      synergy: 'Digititup Tech applies process-mining methodologies to audit operational bottlenecks for enterprise clients.',
      url: 'https://celonis.com'
    },
    {
      id: 'klarna',
      name: 'Klarna',
      valuation: '$14.6 Billion',
      valNumber: 14.6,
      category: 'Fintech & Payments',
      city: 'Stockholm',
      country: 'Sweden',
      lat: 59.3293,
      lng: 18.0686,
      founded: 2005,
      founders: 'Sebastian Siemiatkowski, Niklas Adalberth, Victor Jacobsson',
      investors: 'Sequoia Capital, Silver Lake, SoftBank Vision Fund, Commonwealth Bank',
      tagline: 'AI-Powered Global Retail Bank & Buy Now Pay Later',
      summary: 'Famous for dramatically reducing corporate operating expenses by implementing generative AI customer agents across 150M global shoppers.',
      synergy: 'Case study taught in Digititup Academy on how AI automation radically improves operational EBITDA.',
      url: 'https://klarna.com'
    },

    // --- ASIA PACIFIC & SOUTH ASIA ---
    {
      id: 'bytedance',
      name: 'ByteDance',
      valuation: '$225 Billion',
      valNumber: 225,
      category: 'Media & Creator Tech',
      city: 'Beijing',
      country: 'China',
      lat: 39.9042,
      lng: 116.4074,
      founded: 2012,
      founders: 'Zhang Yiming, Liang Rubo',
      investors: 'Sequoia Capital China, General Atlantic, SoftBank, Coatue',
      tagline: 'Algorithmic Content Recommendation & Global TikTok Machine',
      summary: 'Engineered the world\'s most powerful attention engine through hyper-personalized machine learning. Scaled TikTok and Douyin to over 1.5 Billion monthly active users.',
      synergy: 'Digititup Media\'s narrative framework relies on reverse-engineering ByteDance algorithmic retention curves to maximize viral video reach.',
      url: 'https://bytedance.com'
    },
    {
      id: 'canva',
      name: 'Canva',
      valuation: '$26.0 Billion',
      valNumber: 26,
      category: 'Media & Creator Tech',
      city: 'Sydney',
      country: 'Australia',
      lat: -33.8688,
      lng: 151.2093,
      founded: 2013,
      founders: 'Melanie Perkins, Cliff Obrecht, Cameron Adams',
      investors: 'Sequoia Capital, Bessemer Venture Partners, Blackbird Ventures, Felicis',
      tagline: 'Democratizing Visual Design for 190M+ Users Worldwide',
      summary: 'Empowered non-designers globally to create world-class visual media through intuitive drag-and-drop templates and integrated AI magic tools.',
      synergy: 'A core productivity stack taught in Digititup Academy to help local students launch profitable freelance design careers.',
      url: 'https://canva.com'
    },
    {
      id: 'phonepe',
      name: 'PhonePe',
      valuation: '$12.0 Billion',
      valNumber: 12,
      category: 'Fintech & Payments',
      city: 'Bengaluru',
      country: 'India',
      lat: 12.9716,
      lng: 77.5946,
      founded: 2015,
      founders: 'Sameer Nigam, Rahul Chari, Burzin Engineer',
      investors: 'Walmart, General Atlantic, Ribbit Capital, TVS Capital Funds',
      tagline: 'Dominant UPI Payment Network Processing 50%+ of India\'s Digital Volume',
      summary: 'Processes over 7 Billion transactions per month across millions of merchant QR codes, driving India\'s cashless financial revolution.',
      synergy: 'Demonstrates the power of building digital infrastructure on top of open government rails like UPI, highly relevant to Nepal\'s emerging Fonepay ecosystem.',
      url: 'https://phonepe.com'
    },
    {
      id: 'postman',
      name: 'Postman',
      valuation: '$5.6 Billion',
      valNumber: 5.6,
      category: 'Enterprise SaaS',
      city: 'Bengaluru / San Francisco',
      country: 'India / USA',
      lat: 12.9352,
      lng: 77.6245,
      founded: 2014,
      founders: 'Abhinav Asthana, Ankit Sobti, Abhijit Kane',
      investors: 'Nexus Venture Partners, CRV, Insight Partners, Coatue Management',
      tagline: 'World\'s Leading API Collaboration Platform with 30M+ Developers',
      summary: 'Started as a simple Chrome side-project in Bengaluru and scaled into the indispensable developer tool used by 98% of the Fortune 500.',
      synergy: 'A beacon for South Asian engineering founders proving that world-class developer software can be born in the subcontinent.',
      url: 'https://postman.com'
    },
    {
      id: 'razorpay',
      name: 'Razorpay',
      valuation: '$7.5 Billion',
      valNumber: 7.5,
      category: 'Fintech & Payments',
      city: 'Bengaluru',
      country: 'India',
      lat: 12.9279,
      lng: 77.6271,
      founded: 2014,
      founders: 'Harshil Mathur, Shashank Kumar',
      investors: 'Y Combinator, Tiger Global, Sequoia Capital India, Lone Pine Capital, GIC',
      tagline: 'Full-Stack Financial Services & Payment Gateway Engine',
      summary: 'Empowers millions of digital businesses with payment acceptance, automated vendor payouts, neo-banking, and business credit cards.',
      synergy: 'Founded by IIT Roorkee alumni, mirroring the elite technical engineering pedigree of IOE Pulchowk builders.',
      url: 'https://razorpay.com'
    },
    {
      id: 'shein',
      name: 'SHEIN',
      valuation: '$66.0 Billion',
      valNumber: 66,
      category: 'Consumer & E-Commerce',
      city: 'Singapore',
      country: 'Singapore',
      lat: 1.3521,
      lng: 103.8198,
      founded: 2008,
      founders: 'Chris Xu',
      investors: 'Sequoia Capital China, General Atlantic, Tiger Global, Mubadala',
      tagline: 'On-Demand Realtime Fashion & Algorithmic Supply Chain',
      summary: 'Replaced traditional 6-month fashion manufacturing with real-time digital demand testing and micro-batch manufacturing cycles.',
      synergy: 'A masterclass in programmatic, data-driven consumer commerce.',
      url: 'https://shein.com'
    },
    {
      id: 'grab',
      name: 'Grab',
      valuation: '$15.0 Billion',
      valNumber: 15,
      category: 'Consumer & Mobility',
      city: 'Singapore',
      country: 'Singapore',
      lat: 1.2903,
      lng: 103.8520,
      founded: 2012,
      founders: 'Anthony Tan, Tan Hooi Ling',
      investors: 'SoftBank, Toyota, Didi Chuxing, Uber, GGV Capital',
      tagline: 'Southeast Asia\'s Everyday Everything Superapp',
      summary: 'Defeated Uber across Southeast Asia and unified ride-hailing, food delivery, and digital banking across 8 nations.',
      synergy: 'The gold standard of building defensive localized moats in emerging Asian economies.',
      url: 'https://grab.com'
    },
    {
      id: 'flipkart',
      name: 'Flipkart',
      valuation: '$35.0 Billion',
      valNumber: 35,
      category: 'Consumer & E-Commerce',
      city: 'Bengaluru',
      country: 'India',
      lat: 12.9350,
      lng: 77.6950,
      founded: 2007,
      founders: 'Sachin Bansal, Binny Bansal',
      investors: 'Walmart, Tiger Global, Accel, SoftBank, Tencent',
      tagline: 'Pioneer of India\'s Digital Commerce Revolution',
      summary: 'Invented Cash-on-Delivery in South Asia and created the logistics backbone that digitized hundreds of millions of consumers.',
      synergy: 'Demonstrated how solving local payment and delivery trust unlocks massive market opportunity.',
      url: 'https://flipkart.com'
    },
    {
      id: 'zepto',
      name: 'Zepto',
      valuation: '$5.0 Billion',
      valNumber: 5,
      category: 'Consumer & E-Commerce',
      city: 'Mumbai',
      country: 'India',
      lat: 19.0760,
      lng: 72.8777,
      founded: 2021,
      founders: 'Aadit Palicha, Kaivalya Vohra',
      investors: 'StepStone Group, Nexus Venture Partners, Glade Brook Capital, Lightspeed',
      tagline: 'Hyperlocal 10-Minute Dark Store Instant Commerce',
      summary: 'Founded by two 19-year-old Stanford dropouts who built a billion-dollar supply chain logistics network powered by micro-warehouses and algorithmic routing.',
      synergy: 'Exemplifies the unstoppable momentum of young technical founders executing with obsessive velocity.',
      url: 'https://zeptonow.com'
    },

    // --- LATIN AMERICA & MIDDLE EAST ---
    {
      id: 'nubank',
      name: 'Nubank',
      valuation: '$50.0 Billion',
      valNumber: 50,
      category: 'Fintech & Payments',
      city: 'São Paulo',
      country: 'Brazil',
      lat: -23.5505,
      lng: -46.6333,
      founded: 2013,
      founders: 'David Vélez, Cristina Junqueira, Edward Wible',
      investors: 'Berkshire Hathaway, Sequoia Capital, Kaszek Ventures, DST Global, Tencent',
      tagline: 'Latin America\'s Digital Banking Giant with 100M+ Customers',
      summary: 'Challenged Brazil\'s predatory oligopoly banks with zero-fee purple credit cards and built the largest neobank in the Western Hemisphere.',
      synergy: 'Warren Buffett\'s Berkshire Hathaway invested $1B into Nubank—a validation of customer-centric digital products.',
      url: 'https://nubank.com.br'
    },
    {
      id: 'rappi',
      name: 'Rappi',
      valuation: '$5.2 Billion',
      valNumber: 5.2,
      category: 'Consumer & Mobility',
      city: 'Bogotá',
      country: 'Colombia',
      lat: 4.7110,
      lng: -74.0721,
      founded: 2015,
      founders: 'Simón Borrero, Sebastian Mejia, Felipe Villamarin',
      investors: 'SoftBank, Andreessen Horowitz, Sequoia Capital, Y Combinator',
      tagline: 'Latin America\'s Multimodal On-Demand Delivery Platform',
      summary: 'Delivers groceries, pharmaceuticals, restaurant food, and cash across 9 countries, acting as the daily operating system for Latin American cities.',
      synergy: 'Showcases how high-frequency delivery establishes an unbeatable moat for digital banking services.',
      url: 'https://rappi.com'
    },
    {
      id: 'careem',
      name: 'Careem',
      valuation: '$3.1 Billion',
      valNumber: 3.1,
      category: 'Consumer & Mobility',
      city: 'Dubai',
      country: 'United Arab Emirates',
      lat: 25.2048,
      lng: 55.2708,
      founded: 2012,
      founders: 'Mudassir Sheikha, Magnus Olsson, Abdulla Elyas',
      investors: 'Uber (Acquired Mobility), e& (Etisalat), Kingdom Holding, Rakuten',
      tagline: 'The Pioneer Tech Unicorn of the Greater Middle East',
      summary: 'Scaled ride-hailing across 100+ cities in the Middle East, North Africa, and Pakistan by pioneering local cash-matching and localized street navigation.',
      synergy: 'Proves that regional engineering hubs can build multi-billion dollar exits even against Silicon Valley giants.',
      url: 'https://careem.com'
    },
    {
      id: 'kitopi',
      name: 'Kitopi',
      valuation: '$1.5 Billion',
      valNumber: 1.5,
      category: 'Consumer & E-Commerce',
      city: 'Dubai',
      country: 'United Arab Emirates',
      lat: 25.0754,
      lng: 55.1888,
      founded: 2018,
      founders: 'Mohamad Ballout, Saman Darkan, Bader Ataya, Andres Arenas',
      investors: 'SoftBank Vision Fund 2, Chimera Investment, B.Riley Financial',
      tagline: 'Managed Smart Cloud Kitchen & FoodTech Network',
      summary: 'Cooks and scales food brands through proprietary Smart Kitchen Operating System (SKOS), serving thousands of orders in under 30 minutes.',
      synergy: 'A prime example of leveraging proprietary software to operate physical businesses at software-like margins.',
      url: 'https://kitopi.com'
    },
    {
      id: 'dji',
      name: 'DJI',
      valuation: '$15.0 Billion',
      valNumber: 15,
      category: 'Aerospace & Frontier Tech',
      city: 'Shenzhen',
      country: 'China',
      lat: 22.5431,
      lng: 114.0579,
      founded: 2006,
      founders: 'Frank Wang',
      investors: 'Sequoia Capital China, Accel, Kleiner Perkins',
      tagline: 'Global Monopolist in Civilian Drone Aerial Robotics (70%+ Market Share)',
      summary: 'Engineering marvel combining brushless motors, gimbal stabilization, computer vision, and high-bandwidth image transmission.',
      synergy: 'DJI drones and gimbals form the backbone of Digititup Media\'s high-retention documentary field cinematography.',
      url: 'https://dji.com'
    }
  ];

  /* ==========================================================================
     2. Category Color Mapping & Investment Corridors
     ========================================================================== */
  const CATEGORY_COLORS = {
    'AI & Foundation Models': '#4ade80',     // Emerald highlight
    'Aerospace & Frontier Tech': '#38bdf8',  // Cyan sky
    'Fintech & Payments': '#fbbf24',        // Amber gold
    'Media & Creator Tech': '#f43f5e',      // Rose red
    'Enterprise SaaS': '#a855f7',           // Purple
    'Consumer & E-Commerce': '#3b82f6',     // Royal blue
    'Consumer & Mobility': '#06b6d4'        // Teal
  };

  const INVESTMENT_ARCS = [
    { startLat: 37.7749, startLng: -122.4194, endLat: 51.5074, endLng: -0.1278, color: 0x4ade80 }, // SF -> London
    { startLat: 37.7749, startLng: -122.4194, endLat: 12.9716, endLng: 77.5946, color: 0xfbbf24 },  // SF -> Bengaluru
    { startLat: 37.7749, startLng: -122.4194, endLat: 1.3521, endLng: 103.8198, color: 0x38bdf8 },  // SF -> Singapore
    { startLat: 51.5074, startLng: -0.1278, endLat: 48.8566, endLng: 2.3522, color: 0x4ade80 },     // London -> Paris
    { startLat: 51.5074, startLng: -0.1278, endLat: 12.9716, endLng: 77.5946, color: 0xfbbf24 },    // London -> Bengaluru
    { startLat: 12.9716, startLng: 77.5946, endLat: 1.3521, endLng: 103.8198, color: 0x38bdf8 },    // Bengaluru -> Singapore
    { startLat: 1.3521, startLng: 103.8198, endLat: -33.8688, endLng: 151.2093, color: 0x4ade80 },  // Singapore -> Sydney
    { startLat: 37.7749, startLng: -122.4194, endLat: -23.5505, endLng: -46.6333, color: 0xfbbf24 },// SF -> São Paulo
    { startLat: 51.5074, startLng: -0.1278, endLat: 25.2048, endLng: 55.2708, color: 0x38bdf8 },    // London -> Dubai
    { startLat: 39.9042, startLng: 116.4074, endLat: 1.3521, endLng: 103.8198, color: 0xf43f5e }   // Beijing -> Singapore
  ];

  /* ==========================================================================
     3. State Management
     ========================================================================== */
  const EARTH_RADIUS = 100;
  // Default to 'unicorns' so clicking in points shows UNICORNS immediately!
  let viewMode = 'unicorns'; // 'unicorns' (Companies) or 'countries' (WPR Ranking)
  let activeFilter = 'All';
  let searchQuery = '';
  let selectedEntity = null; // Either a Unicorn object or a Country object
  let isAutoRotating = true;

  // Three.js Core Variables
  let scene, camera, renderer;
  let earthMesh, cloudsMesh, atmosphereMesh;
  let earthGroup;
  let beaconsGroup, arcsGroup;
  let interactiveHitboxes = []; // Precision hitboxes for raycasting
  let textureLoader;

  // Camera Orbit Interaction Variables
  let isDragging = false;
  let dragDistance = 0;
  let prevMousePos = { x: 0, y: 0 };
  let currentRotation = { x: 0.25, y: -0.8 };
  let targetRotation = { x: 0.25, y: -0.8 };
  let cameraDistance = 250;
  let targetCameraDistance = 250;
  let flyToTarget = null;
  let flyToProgress = 1;

  // Raycasting
  const raycaster = new THREE.Raycaster();
  const mouse = new THREE.Vector2(-999, -999);
  let hoveredHitbox = null;

  /* ==========================================================================
     4. Spherical Coordinate Conversion
     ========================================================================== */
  function latLngToVector3(lat, lng, radius, altitude) {
    if (altitude === undefined) altitude = 0;
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lng + 180) * (Math.PI / 180);
    const r = radius + altitude;

    const x = -r * Math.sin(phi) * Math.cos(theta);
    const y =  r * Math.cos(phi);
    const z =  r * Math.sin(phi) * Math.sin(theta);
    return new THREE.Vector3(x, y, z);
  }

  /* ==========================================================================
     5. 3D Google Earth Initialization
     ========================================================================== */
  function initGoogleEarth() {
    const container = document.getElementById('globeContainer');
    if (!container) return;

    updateUI();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(45, width / height, 1, 3000);
    camera.position.set(0, 0, cameraDistance);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x040608, 1);
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Sunlight & Space Lighting
    const sunLight = new THREE.DirectionalLight(0xffffff, 1.4);
    sunLight.position.set(250, 150, 200);
    scene.add(sunLight);

    const ambientLight = new THREE.AmbientLight(0x2a3d4f, 0.95);
    scene.add(ambientLight);

    const emeraldRimLight = new THREE.DirectionalLight(0x018d2e, 0.6);
    emeraldRimLight.position.set(-200, -80, -100);
    scene.add(emeraldRimLight);

    earthGroup = new THREE.Group();
    earthGroup.rotation.x = currentRotation.x;
    earthGroup.rotation.y = currentRotation.y;
    scene.add(earthGroup);

    textureLoader = new THREE.TextureLoader();

    // 1. Photorealistic NASA Satellite Earth
    const earthGeo = new THREE.SphereGeometry(EARTH_RADIUS, 64, 64);
    const earthMat = new THREE.MeshStandardMaterial({
      roughness: 0.7,
      metalness: 0.1
    });

    textureLoader.load('assets/img/earth/earth_day.jpg', function(texture) {
      earthMat.map = texture;
      earthMat.needsUpdate = true;
    });
    textureLoader.load('assets/img/earth/earth_topology.png', function(bumpTex) {
      earthMat.bumpMap = bumpTex;
      earthMat.bumpScale = 1.2;
      earthMat.needsUpdate = true;
    });

    earthMesh = new THREE.Mesh(earthGeo, earthMat);
    earthGroup.add(earthMesh);

    // 2. Translucent Orbiting Cloud Layer
    const cloudsGeo = new THREE.SphereGeometry(EARTH_RADIUS * 1.008, 64, 64);
    const cloudsMat = new THREE.MeshStandardMaterial({
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending
    });
    textureLoader.load('assets/img/earth/earth_clouds.png', function(cloudsTex) {
      cloudsMat.map = cloudsTex;
      cloudsMat.needsUpdate = true;
    });
    cloudsMesh = new THREE.Mesh(cloudsGeo, cloudsMat);
    earthGroup.add(cloudsMesh);

    // 3. Atmospheric Fresnel Rim Glow (#018d2e emerald rim)
    const atmosGeo = new THREE.SphereGeometry(EARTH_RADIUS * 1.035, 64, 64);
    const atmosMat = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec3 vNormal;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vNormal;
        void main() {
          float intensity = pow(0.75 - dot(vNormal, vec3(0, 0, 1.0)), 2.2);
          gl_FragColor = vec4(0.01, 0.55, 0.28, 1.0) * intensity * 1.4;
        }
      `,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true
    });
    atmosphereMesh = new THREE.Mesh(atmosGeo, atmosMat);
    scene.add(atmosphereMesh);

    // 4. 3D Starfield
    createStarfield();

    // 5. Beacons & Hitboxes
    beaconsGroup = new THREE.Group();
    earthGroup.add(beaconsGroup);
    rebuild3DBeacons();

    // 6. 3D Investment Arcs
    arcsGroup = new THREE.Group();
    earthGroup.add(arcsGroup);
    create3DInvestmentArcs();

    // 7. Interaction Controls
    setupInteractionControls(container);

    // 8. Animation Loop
    animate();
  }

  /* ==========================================================================
     6. 3D Starfield
     ========================================================================== */
  function createStarfield() {
    const starCount = 1500;
    const starGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(starCount * 3);
    const colors = new Float32Array(starCount * 3);

    for (let i = 0; i < starCount; i++) {
      const radius = 600 + Math.random() * 400;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos((Math.random() * 2) - 1);

      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.cos(phi);
      positions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);

      const tint = Math.random();
      if (tint > 0.85) {
        colors[i * 3] = 0.33; colors[i * 3 + 1] = 0.85; colors[i * 3 + 2] = 0.51; // Emerald
      } else if (tint > 0.7) {
        colors[i * 3] = 0.38; colors[i * 3 + 1] = 0.74; colors[i * 3 + 2] = 0.97; // Cyan
      } else {
        colors[i * 3] = 0.95; colors[i * 3 + 1] = 0.98; colors[i * 3 + 2] = 1.0;  // White
      }
    }

    starGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    starGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const starMat = new THREE.PointsMaterial({
      size: 1.8,
      vertexColors: true,
      transparent: true,
      opacity: 0.85
    });

    scene.add(new THREE.Points(starGeo, starMat));
  }

  /* ==========================================================================
     7. 3D Beacons with Precision Hitboxes
     ========================================================================== */
  function rebuild3DBeacons() {
    if (!beaconsGroup) return;

    while (beaconsGroup.children.length > 0) {
      beaconsGroup.remove(beaconsGroup.children[0]);
    }
    interactiveHitboxes = [];

    if (viewMode === 'countries') {
      // --- COUNTRIES MODE (55 Nations) ---
      const countries = getFilteredCountries();

      countries.forEach(function (c) {
        const rootPos = latLngToVector3(c.lat, c.lng, EARTH_RADIUS, 0);
        const normal = rootPos.clone().normalize();
        const pillarHeight = Math.max(3.2, Math.min(13.0, Math.log2(c.count + 1) * 2.2));

        const holder = new THREE.Group();

        let colorHex = '#4ade80';
        if (c.rank <= 3) colorHex = '#55d982';
        else if (c.rank <= 10) colorHex = '#fbbf24';
        else if (c.rank <= 25) colorHex = '#38bdf8';
        else colorHex = '#a855f7';

        const threeColor = new THREE.Color(colorHex);

        // Vertical Light Pillar
        const pillar = new THREE.Mesh(
          new THREE.CylinderGeometry(0.3, 0.75, pillarHeight, 8),
          new THREE.MeshBasicMaterial({ color: threeColor, transparent: true, opacity: 0.75 })
        );
        pillar.position.copy(rootPos.clone().add(normal.clone().multiplyScalar(pillarHeight / 2)));
        pillar.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
        holder.add(pillar);

        // Head Gemstone
        const isSelected = selectedEntity && selectedEntity.country === c.country;
        const headRadius = isSelected ? 2.4 : Math.max(1.3, Math.min(2.1, Math.log10(c.count + 1) * 1.5));
        const head = new THREE.Mesh(
          new THREE.SphereGeometry(headRadius, 16, 16),
          new THREE.MeshStandardMaterial({
            color: isSelected ? 0xffffff : threeColor,
            emissive: threeColor,
            emissiveIntensity: 0.95,
            roughness: 0.15
          })
        );
        head.position.copy(rootPos.clone().add(normal.clone().multiplyScalar(pillarHeight + headRadius * 0.8)));
        holder.add(head);

        // Base Pulse Ring
        const ring = new THREE.Mesh(
          new THREE.RingGeometry(1.0, 2.5, 24),
          new THREE.MeshBasicMaterial({ color: threeColor, transparent: true, opacity: 0.65, side: THREE.DoubleSide })
        );
        ring.position.copy(rootPos.clone().add(normal.clone().multiplyScalar(0.2)));
        ring.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
        holder.add(ring);

        // Generous Precision Hitbox (Guarantees effortless clicks)
        const hitbox = new THREE.Mesh(
          new THREE.SphereGeometry(4.6, 8, 8),
          new THREE.MeshBasicMaterial({ visible: false })
        );
        hitbox.position.copy(head.position);
        hitbox.userData = { type: 'country', country: c, visualHead: head, holder: holder };
        holder.add(hitbox);
        interactiveHitboxes.push(hitbox);

        beaconsGroup.add(holder);
      });
    } else {
      // --- UNICORNS MODE (Companies with Exact City Coordinates) ---
      const unicorns = getFilteredUnicorns();

      unicorns.forEach(function (u) {
        const colorHex = CATEGORY_COLORS[u.category] || '#4ade80';
        const threeColor = new THREE.Color(colorHex);

        const rootPos = latLngToVector3(u.lat, u.lng, EARTH_RADIUS, 0);
        const normal = rootPos.clone().normalize();
        const pillarHeight = 5.2;

        const holder = new THREE.Group();

        // Pillar
        const pillar = new THREE.Mesh(
          new THREE.CylinderGeometry(0.25, 0.6, pillarHeight, 8),
          new THREE.MeshBasicMaterial({ color: threeColor, transparent: true, opacity: 0.65 })
        );
        pillar.position.copy(rootPos.clone().add(normal.clone().multiplyScalar(pillarHeight / 2)));
        pillar.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
        holder.add(pillar);

        // Head Gemstone
        const isSelected = selectedEntity && selectedEntity.id === u.id;
        const headRadius = isSelected ? 2.3 : 1.4;
        const head = new THREE.Mesh(
          new THREE.SphereGeometry(headRadius, 16, 16),
          new THREE.MeshStandardMaterial({
            color: isSelected ? 0xffffff : threeColor,
            emissive: threeColor,
            emissiveIntensity: 0.95,
            roughness: 0.15
          })
        );
        head.position.copy(rootPos.clone().add(normal.clone().multiplyScalar(pillarHeight + headRadius * 0.8)));
        holder.add(head);

        // Base Pulse Ring
        const ring = new THREE.Mesh(
          new THREE.RingGeometry(0.8, 2.2, 24),
          new THREE.MeshBasicMaterial({ color: threeColor, transparent: true, opacity: 0.7, side: THREE.DoubleSide })
        );
        ring.position.copy(rootPos.clone().add(normal.clone().multiplyScalar(0.2)));
        ring.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
        holder.add(ring);

        // Precision Hitbox
        const hitbox = new THREE.Mesh(
          new THREE.SphereGeometry(4.6, 8, 8),
          new THREE.MeshBasicMaterial({ visible: false })
        );
        hitbox.position.copy(head.position);
        hitbox.userData = { type: 'unicorn', unicorn: u, visualHead: head, holder: holder };
        holder.add(hitbox);
        interactiveHitboxes.push(hitbox);

        beaconsGroup.add(holder);
      });
    }
  }

  /* ==========================================================================
     8. 3D Investment Arcs
     ========================================================================== */
  function create3DInvestmentArcs() {
    while (arcsGroup.children.length > 0) {
      arcsGroup.remove(arcsGroup.children[0]);
    }

    INVESTMENT_ARCS.forEach(function (arc) {
      const v1 = latLngToVector3(arc.startLat, arc.startLng, EARTH_RADIUS);
      const v2 = latLngToVector3(arc.endLat, arc.endLng, EARTH_RADIUS);

      const distance = v1.distanceTo(v2);
      const mid = v1.clone().add(v2).multiplyScalar(0.5);
      const alt = distance * 0.28;
      mid.normalize().multiplyScalar(EARTH_RADIUS + alt);

      const curve = new THREE.QuadraticBezierCurve3(v1, mid, v2);
      const points = curve.getPoints(48);
      const curveGeo = new THREE.BufferGeometry().setFromPoints(points);

      const curveMat = new THREE.LineBasicMaterial({
        color: arc.color,
        transparent: true,
        opacity: 0.45,
        linewidth: 1
      });

      arcsGroup.add(new THREE.Line(curveGeo, curveMat));
    });
  }

  /* ==========================================================================
     9. Google Earth Controls (Orbit, Zoom, Inertia, Precision Click)
     ========================================================================== */
  function setupInteractionControls(container) {
    container.addEventListener('mousedown', function (e) {
      if (e.button !== 0) return;
      isDragging = true;
      dragDistance = 0;
      isAutoRotating = false;
      updateRotateBtnUI();
      prevMousePos = { x: e.clientX, y: e.clientY };
      container.style.cursor = 'grabbing';
    });

    window.addEventListener('mousemove', function (e) {
      const rect = container.getBoundingClientRect();
      const xInView = e.clientX - rect.left;
      const yInView = e.clientY - rect.top;

      mouse.x = (xInView / container.clientWidth) * 2 - 1;
      mouse.y = -(yInView / container.clientHeight) * 2 + 1;

      if (isDragging) {
        const deltaX = e.clientX - prevMousePos.x;
        const deltaY = e.clientY - prevMousePos.y;
        dragDistance += Math.hypot(deltaX, deltaY);

        targetRotation.y += deltaX * 0.005;
        targetRotation.x += deltaY * 0.005;
        targetRotation.x = Math.max(-1.3, Math.min(1.3, targetRotation.x));

        prevMousePos = { x: e.clientX, y: e.clientY };
      } else {
        checkBeaconHover(e.clientX, e.clientY);
      }
    });

    window.addEventListener('mouseup', function () {
      if (isDragging) {
        isDragging = false;
        container.style.cursor = hoveredHitbox ? 'pointer' : 'grab';
      }
    });

    // Click handler with dragDistance filter
    container.addEventListener('click', function (e) {
      if (dragDistance > 6) return; // Ignore drag releases!

      if (hoveredHitbox && hoveredHitbox.userData) {
        const data = hoveredHitbox.userData;
        if (data.type === 'unicorn' && data.unicorn) {
          selectUnicorn(data.unicorn, true);
        } else if (data.type === 'country' && data.country) {
          selectCountry(data.country, true);
        }
      }
    });

    container.addEventListener('wheel', function (e) {
      e.preventDefault();
      targetCameraDistance += e.deltaY * 0.22;
      targetCameraDistance = Math.max(116, Math.min(380, targetCameraDistance));
    }, { passive: false });

    // Touch support
    let initialPinchDistance = null;

    container.addEventListener('touchstart', function (e) {
      isAutoRotating = false;
      dragDistance = 0;
      updateRotateBtnUI();
      if (e.touches.length === 1) {
        isDragging = true;
        prevMousePos = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      } else if (e.touches.length === 2) {
        isDragging = false;
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        initialPinchDistance = Math.hypot(dx, dy);
      }
    }, { passive: true });

    container.addEventListener('touchmove', function (e) {
      if (e.touches.length === 1 && isDragging) {
        const deltaX = e.touches[0].clientX - prevMousePos.x;
        const deltaY = e.touches[0].clientY - prevMousePos.y;
        dragDistance += Math.hypot(deltaX, deltaY);

        targetRotation.y += deltaX * 0.006;
        targetRotation.x += deltaY * 0.006;
        targetRotation.x = Math.max(-1.3, Math.min(1.3, targetRotation.x));

        prevMousePos = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      } else if (e.touches.length === 2 && initialPinchDistance) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const currentDistance = Math.hypot(dx, dy);
        const diff = initialPinchDistance - currentDistance;

        targetCameraDistance += diff * 0.4;
        targetCameraDistance = Math.max(116, Math.min(380, targetCameraDistance));
        initialPinchDistance = currentDistance;
      }
    }, { passive: true });

    container.addEventListener('touchend', function () {
      isDragging = false;
      initialPinchDistance = null;
    });

    window.addEventListener('resize', function () {
      if (!camera || !renderer || !container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
  }

  /* ==========================================================================
     10. Raycasting & Tooltip
     ========================================================================== */
  const tooltipEl = document.createElement('div');
  tooltipEl.className = 'globe-tooltip-3d';
  tooltipEl.style.display = 'none';
  document.body.appendChild(tooltipEl);

  function checkBeaconHover(screenX, screenY) {
    if (!camera || !interactiveHitboxes.length) return;

    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObjects(interactiveHitboxes);

    if (intersects.length > 0) {
      const hit = intersects[0].object;
      if (hoveredHitbox !== hit) {
        if (hoveredHitbox && hoveredHitbox.userData.visualHead) {
          hoveredHitbox.userData.visualHead.scale.set(1.0, 1.0, 1.0);
        }
        hoveredHitbox = hit;
        if (hit.userData.visualHead) {
          hit.userData.visualHead.scale.set(1.5, 1.5, 1.5);
        }
      }

      const data = hit.userData;
      tooltipEl.style.display = 'block';
      tooltipEl.style.left = (screenX + 16) + 'px';
      tooltipEl.style.top = (screenY - 20) + 'px';

      if (data.type === 'unicorn' && data.unicorn) {
        const u = data.unicorn;
        tooltipEl.innerHTML = [
          '<div class="tt-header">',
            '<strong>' + u.name + '</strong>',
            '<span class="tt-badge">' + u.valuation + '</span>',
          '</div>',
          '<div class="tt-location">📍 <strong>' + u.city + '</strong>, ' + u.country + '</div>',
          '<div class="tt-category" style="color:' + (CATEGORY_COLORS[u.category] || '#4ade80') + '">' + u.category + '</div>',
          '<div class="tt-action">Click to inspect company dossier →</div>'
        ].join('');
      } else if (data.type === 'country' && data.country) {
        const c = data.country;
        tooltipEl.innerHTML = [
          '<div class="tt-header">',
            '<strong>' + c.flag + ' ' + c.country + '</strong>',
            '<span class="tt-badge">Rank #' + c.rank + '</span>',
          '</div>',
          '<div class="tt-location">🦄 <strong>' + c.count + ' Unicorns</strong> (' + c.valuation + ')</div>',
          '<div class="tt-category" style="color:#55d982">Hubs: ' + c.capital_cities + '</div>',
          '<div class="tt-action">Click to inspect country ecosystem →</div>'
        ].join('');
      }

      document.body.style.cursor = 'pointer';
    } else {
      if (hoveredHitbox) {
        if (hoveredHitbox.userData && hoveredHitbox.userData.visualHead) {
          hoveredHitbox.userData.visualHead.scale.set(1.0, 1.0, 1.0);
        }
        hoveredHitbox = null;
      }
      tooltipEl.style.display = 'none';
      document.body.style.cursor = 'default';
    }
  }

  /* ==========================================================================
     11. Smooth Animation Loop & Fly-To Controller
     ========================================================================== */
  function animate() {
    requestAnimationFrame(animate);

    if (isAutoRotating && !isDragging && flyToProgress >= 1) {
      targetRotation.y += 0.0012;
    }

    if (flyToProgress < 1) {
      flyToProgress += 0.035;
      const ease = easeOutCubic(Math.min(flyToProgress, 1));

      currentRotation.x = flyToTarget.startX + (flyToTarget.rotX - flyToTarget.startX) * ease;
      currentRotation.y = flyToTarget.startY + (flyToTarget.rotY - flyToTarget.startY) * ease;
      cameraDistance = flyToTarget.startDist + (flyToTarget.distance - flyToTarget.startDist) * ease;
      targetRotation.x = currentRotation.x;
      targetRotation.y = currentRotation.y;
      targetCameraDistance = cameraDistance;
    } else {
      currentRotation.y += (targetRotation.y - currentRotation.y) * 0.06;
      currentRotation.x += (targetRotation.x - currentRotation.x) * 0.06;
      cameraDistance += (targetCameraDistance - cameraDistance) * 0.08;
    }

    if (earthGroup) {
      earthGroup.rotation.y = currentRotation.y;
      earthGroup.rotation.x = currentRotation.x;
    }

    if (cloudsMesh) {
      cloudsMesh.rotation.y += 0.0004;
    }

    if (camera) {
      camera.position.z = cameraDistance;
    }

    if (renderer && scene && camera) {
      renderer.render(scene, camera);
    }
  }

  function easeOutCubic(t) {
    return 1 - Math.pow(1 - t, 3);
  }

  /* ==========================================================================
     12. Fly-To Coordinates (Google Earth Style Camera Zoom)
     ========================================================================== */
  function flyToCoordinate(lat, lng, zoomDistance) {
    if (zoomDistance === undefined) zoomDistance = 124;
    // Precise spherical centering formula: rx = lat, ry = -90 - lng
    const destRotX = lat * (Math.PI / 180);
    const destRotY = (-90 - lng) * (Math.PI / 180);

    // Shortest angular path interpolation
    let diffY = (destRotY - currentRotation.y) % (Math.PI * 2);
    if (diffY > Math.PI) diffY -= Math.PI * 2;
    if (diffY < -Math.PI) diffY += Math.PI * 2;
    const targetY = currentRotation.y + diffY;

    let diffX = (destRotX - currentRotation.x) % (Math.PI * 2);
    if (diffX > Math.PI) diffX -= Math.PI * 2;
    if (diffX < -Math.PI) diffX += Math.PI * 2;
    const targetX = currentRotation.x + diffX;

    flyToTarget = {
      startX: currentRotation.x,
      startY: currentRotation.y,
      rotX: Math.max(-1.3, Math.min(1.3, targetX)),
      rotY: targetY,
      startDist: cameraDistance,
      distance: zoomDistance
    };
    flyToProgress = 0;
  }

  /* ==========================================================================
     13. Filter & Search Logic
     ========================================================================== */
  function getFilteredCountries() {
    const q = searchQuery.toLowerCase().trim();
    return COUNTRIES_DATA.filter(function (c) {
      if (!q) return true;
      return (
        c.country.toLowerCase().includes(q) ||
        c.capital_cities.toLowerCase().includes(q) ||
        c.top.toLowerCase().includes(q)
      );
    });
  }

  function getFilteredUnicorns() {
    return UNICORNS_DATA.filter(function (u) {
      const matchesCategory = (activeFilter === 'All' || u.category === activeFilter);
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || (
        u.name.toLowerCase().includes(q) ||
        u.city.toLowerCase().includes(q) ||
        u.country.toLowerCase().includes(q) ||
        u.category.toLowerCase().includes(q)
      );
      return matchesCategory && matchesSearch;
    });
  }

  function updateUI() {
    const countDisplay = document.getElementById('activeCountDisplay');
    const titleRow = document.getElementById('sidebarTitle');

    if (viewMode === 'unicorns') {
      const unicorns = getFilteredUnicorns();
      if (countDisplay) countDisplay.innerHTML = 'Showing: <strong>' + unicorns.length + ' Unicorns</strong>';
      if (titleRow) titleRow.textContent = 'Top Unicorns';
      renderUnicornsList(unicorns);
    } else {
      const countries = getFilteredCountries();
      if (countDisplay) countDisplay.innerHTML = 'Showing: <strong>' + countries.length + ' Nations (1,286 🦄)</strong>';
      if (titleRow) titleRow.textContent = 'Global Rankings';
      renderCountriesList(countries);
    }

    rebuild3DBeacons();
  }

  /* ==========================================================================
     14. Select Entity & Open Distinct Drawers
     ========================================================================== */
  function selectUnicorn(unicorn, shouldFlyTo) {
    if (shouldFlyTo === undefined) shouldFlyTo = true;
    selectedEntity = unicorn;

    if (shouldFlyTo) {
      isAutoRotating = false;
      updateRotateBtnUI();
      // Deep, precise zoom right to that unicorn's exact city location
      flyToCoordinate(unicorn.lat, unicorn.lng, 124);
    }

    rebuild3DBeacons();
    openUnicornDrawer(unicorn);
  }

  function selectCountry(country, shouldFlyTo) {
    if (shouldFlyTo === undefined) shouldFlyTo = true;
    selectedEntity = country;

    if (shouldFlyTo) {
      isAutoRotating = false;
      updateRotateBtnUI();
      flyToCoordinate(country.lat, country.lng, 142);
    }

    rebuild3DBeacons();
    openCountryDrawer(country);
  }

  /* ==========================================================================
     15. Venture Detail Slide-In Glass Drawer
     ========================================================================== */
  const drawer = document.getElementById('unicornDrawer');
  const drawerBackdrop = document.getElementById('drawerBackdrop');
  const closeBtn = document.getElementById('closeDrawerBtn');

  function openUnicornDrawer(u) {
    if (!drawer) return;

    document.getElementById('drawerCompany').textContent = u.name;
    document.getElementById('drawerValuation').textContent = u.valuation;
    document.getElementById('drawerTagline').textContent = u.tagline;

    // Precise City and Country labels
    document.getElementById('drawerLocationLabel').textContent = 'Headquarters Location';
    document.getElementById('drawerCity').textContent = u.city;
    document.getElementById('drawerCountry').textContent = u.country;
    document.getElementById('drawerCoords').textContent = u.lat.toFixed(2) + '° N, ' + u.lng.toFixed(2) + '° E';

    document.getElementById('drawerCategory').textContent = u.category;
    document.getElementById('drawerCategory').style.borderColor = CATEGORY_COLORS[u.category] || 'var(--primary)';

    document.getElementById('drawerSectionTitle').textContent = 'Venture Dossier & Architecture';
    document.getElementById('drawerSummary').textContent = u.summary;

    document.getElementById('drawerMeta1Label').textContent = 'Key Founders';
    document.getElementById('drawerMeta1Val').textContent = u.founders;

    document.getElementById('drawerMeta2Label').textContent = 'Founded Year';
    document.getElementById('drawerMeta2Val').textContent = u.founded;

    document.getElementById('drawerMeta3Label').textContent = 'Lead Investors / Backers';
    document.getElementById('drawerMeta3Val').textContent = u.investors;

    document.getElementById('drawerSynergy').textContent = u.synergy;

    const link = document.getElementById('drawerLink');
    if (link) {
      link.href = u.url;
      link.textContent = 'Visit ' + u.name + ' Official Website ↗';
    }

    drawer.classList.add('open');
    if (drawerBackdrop) drawerBackdrop.classList.add('open');
  }

  function openCountryDrawer(c) {
    if (!drawer) return;

    const share = ((c.count / 1286) * 100).toFixed(1);

    document.getElementById('drawerCompany').textContent = c.flag + ' ' + c.country;
    document.getElementById('drawerValuation').textContent = c.count + ' Unicorns (' + c.valuation + ')';
    document.getElementById('drawerTagline').textContent = 'Rank #' + c.rank + ' Global Unicorn Ecosystem • ' + share + '% of World Total';

    // Precise Country and Hubs
    document.getElementById('drawerLocationLabel').textContent = 'Key Tech Hub Cities & Country';
    document.getElementById('drawerCity').textContent = c.capital_cities;
    document.getElementById('drawerCountry').textContent = c.country + ' (' + c.code + ')';
    document.getElementById('drawerCoords').textContent = c.lat.toFixed(2) + '° N, ' + c.lng.toFixed(2) + '° E';

    document.getElementById('drawerCategory').textContent = 'World Population Review Rank #' + c.rank;
    document.getElementById('drawerCategory').style.borderColor = 'var(--primary)';

    document.getElementById('drawerSectionTitle').textContent = 'Ecosystem Overview & Flagship Ventures';
    document.getElementById('drawerSummary').textContent = c.country + ' ranks #' + c.rank + ' globally with ' + c.count + ' verified unicorn companies representing ' + c.valuation + ' in total combined market valuation. Key industry leaders include: ' + c.top + '.';

    document.getElementById('drawerMeta1Label').textContent = 'Global Ranking';
    document.getElementById('drawerMeta1Val').textContent = '#' + c.rank + ' Worldwide (' + share + '% of all unicorns)';

    document.getElementById('drawerMeta2Label').textContent = 'Total Unicorns';
    document.getElementById('drawerMeta2Val').textContent = c.count + ' Companies (' + c.valuation + ')';

    document.getElementById('drawerMeta3Label').textContent = 'Major Startup Hubs';
    document.getElementById('drawerMeta3Val').textContent = c.capital_cities;

    document.getElementById('drawerSynergy').textContent = 'Digititup Agency leverages zero-CAC media reach and in-house engineering talent to identify early high-velocity founders operating in or expanding into ' + c.country + ' tech hubs.';

    const link = document.getElementById('drawerLink');
    if (link) {
      link.href = 'https://worldpopulationreview.com/country-rankings/unicorns-by-country';
      link.textContent = 'View World Population Review Official Ranking ↗';
    }

    drawer.classList.add('open');
    if (drawerBackdrop) drawerBackdrop.classList.add('open');
  }

  function closeDetailDrawer() {
    if (drawer) drawer.classList.remove('open');
    if (drawerBackdrop) drawerBackdrop.classList.remove('open');
    selectedEntity = null;
    rebuild3DBeacons();
  }

  if (closeBtn) closeBtn.addEventListener('click', closeDetailDrawer);
  if (drawerBackdrop) drawerBackdrop.addEventListener('click', closeDetailDrawer);

  /* ==========================================================================
     16. Directory Lists (Unicorns vs Countries)
     ========================================================================== */
  function renderUnicornsList(unicorns) {
    const listContainer = document.getElementById('unicornListContainer');
    if (!listContainer) return;

    if (!unicorns.length) {
      listContainer.innerHTML = '<div class="empty-state"><p>No unicorns match your criteria.</p></div>';
      return;
    }

    listContainer.innerHTML = unicorns.map(function (u) {
      const isActive = (selectedEntity && selectedEntity.id === u.id);
      return [
        '<div class="unicorn-list-item ' + (isActive ? 'active' : '') + '" data-id="' + u.id + '">',
          '<div class="uli-top">',
            '<strong class="uli-name">' + u.name + '</strong>',
            '<span class="uli-val">' + u.valuation + '</span>',
          '</div>',
          '<div class="uli-meta">',
            '<span>📍 <strong>' + u.city + '</strong>, ' + u.country + '</span>',
            '<span class="uli-dot" style="background:' + (CATEGORY_COLORS[u.category] || '#4ade80') + '"></span>',
            '<span>' + u.category + '</span>',
          '</div>',
        '</div>'
      ].join('');
    }).join('');

    listContainer.querySelectorAll('.unicorn-list-item').forEach(function (item) {
      item.addEventListener('click', function () {
        const id = item.dataset.id;
        const found = UNICORNS_DATA.find(function (u) { return u.id === id; });
        if (found) selectUnicorn(found, true);
      });
    });
  }

  function renderCountriesList(countries) {
    const listContainer = document.getElementById('unicornListContainer');
    if (!listContainer) return;

    if (!countries.length) {
      listContainer.innerHTML = '<div class="empty-state"><p>No country matches your query.</p></div>';
      return;
    }

    listContainer.innerHTML = countries.map(function (c) {
      const isActive = (selectedEntity && selectedEntity.country === c.country);
      return [
        '<div class="unicorn-list-item ' + (isActive ? 'active' : '') + '" data-country="' + c.country + '">',
          '<div class="uli-top">',
            '<strong class="uli-name"><span class="rank-badge">#' + c.rank + '</span> ' + c.flag + ' ' + c.country + '</strong>',
            '<span class="uli-val">' + c.count + ' 🦄</span>',
          '</div>',
          '<div class="uli-meta">',
            '<span>Valuation: <strong style="color:#ffffff">' + c.valuation + '</strong></span>',
            '<span class="uli-dot" style="background:#55d982"></span>',
            '<span class="uli-top-preview">' + c.capital_cities.split(',').slice(0, 2).join(',') + '</span>',
          '</div>',
        '</div>'
      ].join('');
    }).join('');

    listContainer.querySelectorAll('.unicorn-list-item').forEach(function (item) {
      item.addEventListener('click', function () {
        const name = item.dataset.country;
        const found = COUNTRIES_DATA.find(function (c) { return c.country === name; });
        if (found) selectCountry(found, true);
      });
    });
  }

  /* ==========================================================================
     17. Mode Switcher (Synchronized Across HUD & Sidebar)
     ========================================================================== */
  function setViewMode(newMode) {
    viewMode = newMode;

    // Update all mode buttons
    document.querySelectorAll('.mode-pill, .mode-btn').forEach(function (b) {
      b.classList.toggle('active', b.dataset.mode === viewMode);
    });

    // Show category filter bar only for unicorns
    const catBar = document.querySelector('.category-filter-bar');
    if (catBar) {
      catBar.style.display = (viewMode === 'unicorns') ? 'flex' : 'none';
    }

    closeDetailDrawer();
    updateUI();
  }

  document.querySelectorAll('.mode-pill, .mode-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const m = btn.dataset.mode;
      if (m && m !== viewMode) {
        setViewMode(m);
      }
    });
  });

  const searchInput = document.getElementById('unicornSearch');
  if (searchInput) {
    searchInput.addEventListener('input', function (e) {
      searchQuery = e.target.value;
      updateUI();
    });
  }

  const catBar = document.querySelector('.category-filter-bar');
  if (catBar) {
    catBar.addEventListener('wheel', function (e) {
      if (e.deltaY !== 0) {
        e.preventDefault();
        catBar.scrollLeft += e.deltaY * 0.9;
      }
    }, { passive: false });
  }

  const filterChips = document.querySelectorAll('.filter-chip');
  filterChips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      filterChips.forEach(function (c) { c.classList.remove('active'); });
      chip.classList.add('active');
      activeFilter = chip.dataset.category;
      try {
        chip.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      } catch (err) {}
      updateUI();
    });
  });

  /* ==========================================================================
     18. Region Presets & Camera Toolbar
     ========================================================================== */
  const PRESET_REGIONS = {
    'all': { lat: 20, lng: 10, zoom: 250 },
    'us': { lat: 38, lng: -98, zoom: 170 },
    'europe': { lat: 50, lng: 10, zoom: 165 },
    'southasia': { lat: 20, lng: 78, zoom: 165 },
    'southeastasia': { lat: 4, lng: 103, zoom: 175 },
    'latam': { lat: -15, lng: -55, zoom: 180 }
  };

  const presetBtns = document.querySelectorAll('.preset-btn');
  presetBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      const region = btn.dataset.region;
      if (PRESET_REGIONS[region]) {
        presetBtns.forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        isAutoRotating = false;
        updateRotateBtnUI();
        const p = PRESET_REGIONS[region];
        flyToCoordinate(p.lat, p.lng, p.zoom);
      }
    });
  });

  const rotateBtn = document.getElementById('toggleRotateBtn');
  function updateRotateBtnUI() {
    if (!rotateBtn) return;
    if (isAutoRotating) {
      rotateBtn.classList.add('active');
      rotateBtn.innerHTML = '<span>⏸</span> Pause Orbit';
    } else {
      rotateBtn.classList.remove('active');
      rotateBtn.innerHTML = '<span>▶</span> Auto Orbit';
    }
  }

  if (rotateBtn) {
    rotateBtn.addEventListener('click', function () {
      isAutoRotating = !isAutoRotating;
      updateRotateBtnUI();
    });
  }

  const resetBtn = document.getElementById('resetViewBtn');
  if (resetBtn) {
    resetBtn.addEventListener('click', function () {
      isAutoRotating = true;
      updateRotateBtnUI();
      flyToCoordinate(20, 10, 250);
      closeDetailDrawer();
    });
  }

  /* ==========================================================================
     19. Mobile Drawer & Header Scroll
     ========================================================================== */
  const menuToggle = document.querySelector('.menu-toggle');
  const mobileDrawer = document.querySelector('.mobile-drawer');
  const drawerLinks = document.querySelectorAll('.drawer-link');

  if (menuToggle && mobileDrawer) {
    menuToggle.addEventListener('click', function () {
      menuToggle.classList.toggle('open');
      mobileDrawer.classList.toggle('open');
      document.body.style.overflow = mobileDrawer.classList.contains('open') ? 'hidden' : '';
    });

    drawerLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        menuToggle.classList.remove('open');
        mobileDrawer.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }

  const header = document.querySelector('.site-header');
  function handleScroll() {
    if (window.scrollY > 20) {
      if (header) header.classList.add('scrolled');
    } else {
      if (header) header.classList.remove('scrolled');
    }
  }
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  /* ==========================================================================
     20. Boot
     ========================================================================== */
  window.addEventListener('DOMContentLoaded', function () {
    initGoogleEarth();
  });

})();
